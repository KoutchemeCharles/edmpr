def count_letters(s):
    i = 0
    for char in s:
        i += 1
    return i