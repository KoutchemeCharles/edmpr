def count_letters(str):
    return len(str)