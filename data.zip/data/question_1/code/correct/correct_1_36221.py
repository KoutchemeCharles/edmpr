def count_letters(a):
    return len(a)