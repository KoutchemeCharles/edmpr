def count_letters(s):
    counter = 0
    if s == '':
        return 0
    else:
        for c in s:
            counter += 1
    return counter