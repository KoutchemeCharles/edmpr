def count_letters(string_):
    counter = 0
    for i in string_:
        counter += 1
    return counter