def count_letters(s):
    if len(s) == 1:
        return 1
    elif s == '':
        return 0
    return count_letters(s[:1]) + count_letters(s[1:])