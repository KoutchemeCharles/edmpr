def count_letters(line=''):
    return len(line)