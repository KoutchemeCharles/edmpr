def count_letters(s, i=0):
    i += 1
    if i == len(s):
        return 1
    if len(s) > 0:
        return 1 + count_letters(s, i)
    else:
        return 0