def count_letters(s):
    if s == '':
        return 0
    else:
        ns = s[1:]
    return 1 + count_letters(ns)