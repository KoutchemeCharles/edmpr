def count_letters(l):
    return len(l)