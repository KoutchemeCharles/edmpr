def count_letters(string):
    return len(string)