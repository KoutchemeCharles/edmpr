def count_letters(s):
    if s == '':
        return 0
    count = 0
    for ch in s:
        count += 1
    return count