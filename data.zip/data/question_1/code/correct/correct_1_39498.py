def count_letters(s):
    s = list(s)
    if s == []:
        return 0
    else:
        count = 0
        for c in s:
            count += 1
        return count