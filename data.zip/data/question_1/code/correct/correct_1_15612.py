def count_letters(s):
    length = 0
    for i in s:
        length += 1
    return length