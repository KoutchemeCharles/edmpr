def count_letters(str):
    total = 0
    for letters in str:
        total += 1
    return total