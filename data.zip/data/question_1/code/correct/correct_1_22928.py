def count_letters(s):
    total = 0
    for x in s:
        total += 1
    return total