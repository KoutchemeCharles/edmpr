def count_letters(s):
    return len(s)