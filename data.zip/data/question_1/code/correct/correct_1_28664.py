def count_letters(s):
    count = 0
    for i in s:
        count += 1
    return count