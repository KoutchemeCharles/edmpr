def count_letters(s):
    if s == '':
        return 0
    a = 0
    for letter in s:
        a += 1
    return a