def count_letters(a):
    al = list(a)
    tot = 0
    for c in al:
        tot += +1
    return tot