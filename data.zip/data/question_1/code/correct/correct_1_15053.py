def count_letters(s):
    str_len = 0
    for c in s:
        str_len += 1
    return str_len