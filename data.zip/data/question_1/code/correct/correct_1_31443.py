def count_letters(l):
    if l == '':
        return 0
    return 1 + count_letters(l[1:])