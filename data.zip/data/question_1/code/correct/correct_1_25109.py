def count_letters(word, count=0):
    if word == '':
        return count
    else:
        word = word[1:]
    return count_letters(word, count + 1)