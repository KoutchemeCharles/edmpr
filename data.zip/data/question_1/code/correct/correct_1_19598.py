def count_letters(word):
    total = 0
    for c in word:
        total += 1
    return total