def count_letters(s):
    i = 0
    for c in s:
        i += 1
    return i