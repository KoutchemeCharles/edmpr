def count_letters(a):
    if a == '':
        return 0
    a = a[:-1]
    n = 1
    return n + count_letters(a)