def count_letters(x):
    return len(x)