def count_letters(s):
    l = 0
    for e in s:
        l += 1
    return l