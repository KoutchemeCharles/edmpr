def count_letters(s):
    if s == '':
        return 0
    s = s.replace(s[-1], '', 1)
    return count_letters(s) + 1