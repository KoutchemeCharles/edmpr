def count_letters(s):
    count = 0
    for c in s:
        count += 1
    return count