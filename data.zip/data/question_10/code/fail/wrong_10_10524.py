def my_function(a):
    return a[1]


def swap_keys_values(dict):
    l = []
    new_dict = {v: k for k, v in list(dict.items())}

    def my_function(a):
        return a[1]
    for k in new_dict:
        l.append('({} : {})'.format(int(k), new_dict[k]))
    print('[' + ', '.join(sorted(l, key=itemgetter(-2))) + ']')
    print(type(l[1]))